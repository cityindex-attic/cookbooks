# -*- encoding: binary -*-

module ApplicationHelper
end
