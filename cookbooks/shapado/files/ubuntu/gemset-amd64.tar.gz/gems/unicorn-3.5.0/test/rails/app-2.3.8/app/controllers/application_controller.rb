# -*- encoding: binary -*-

class ApplicationController < ActionController::Base
  helper :all
end
