# -*- encoding: binary -*-

class ApplicationController < ActionController::Base
end
