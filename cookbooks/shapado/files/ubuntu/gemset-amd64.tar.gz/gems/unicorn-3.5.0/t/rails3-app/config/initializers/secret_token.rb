# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '71ca844cc99ed2057a65cc6bd66b57fbbf69e8d4aef00072e41c3e896635e99ea485a6ed45f6e846d5547d614235df146a9756920b8b4a1726a53e75cda45bd1'
