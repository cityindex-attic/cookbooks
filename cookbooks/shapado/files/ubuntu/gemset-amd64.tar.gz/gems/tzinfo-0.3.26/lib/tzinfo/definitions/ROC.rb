module TZInfo
  module Definitions
    module ROC
      include TimezoneDefinition
      
      linked_timezone 'ROC', 'Asia/Taipei'
    end
  end
end
