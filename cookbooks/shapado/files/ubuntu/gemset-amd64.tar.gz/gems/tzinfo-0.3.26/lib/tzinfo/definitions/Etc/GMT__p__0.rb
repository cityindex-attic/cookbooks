module TZInfo
  module Definitions
    module Etc
      module GMT__p__0
        include TimezoneDefinition
        
        linked_timezone 'Etc/GMT+0', 'Etc/GMT'
      end
    end
  end
end
