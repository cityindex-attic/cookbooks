module TZInfo
  module Definitions
    module GB
      include TimezoneDefinition
      
      linked_timezone 'GB', 'Europe/London'
    end
  end
end
