# encoding: utf-8
require File.dirname(__FILE__) + '/spec_helper'

describe "warden" do
end
