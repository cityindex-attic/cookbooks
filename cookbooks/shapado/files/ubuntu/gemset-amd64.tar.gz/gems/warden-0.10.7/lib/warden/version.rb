# encoding: utf-8
module Warden
  VERSION = "0.10.7".freeze
end
