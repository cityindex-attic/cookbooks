module Compass::SassExtensions
end

require 'compass/sass_extensions/functions'
require 'compass/sass_extensions/monkey_patches'
