require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('chriseppstein', 'compass-960-plugin', 'ninesixty')

