require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('chriseppstein', 'yui-compass-plugin', 'yui')