# encoding: UTF-8
module Plucky
  Version = '0.3.5'
end