# encoding: UTF-8
require 'plucky/extensions/duplicable'
require 'plucky/extensions/symbol'