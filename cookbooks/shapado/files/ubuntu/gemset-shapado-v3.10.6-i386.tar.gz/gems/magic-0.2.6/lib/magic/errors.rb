module Magic
  # General Exception class
  class Exception < StandardError
  end
end
