require 'rubygems'
require 'test/unit'
require 'lingua/stemmer'
