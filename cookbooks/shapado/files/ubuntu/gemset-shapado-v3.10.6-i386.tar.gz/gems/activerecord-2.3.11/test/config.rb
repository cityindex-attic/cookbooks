TEST_ROOT       = File.expand_path(File.dirname(__FILE__))
ASSETS_ROOT     = TEST_ROOT + "/assets"
FIXTURES_ROOT   = TEST_ROOT + "/fixtures"
MIGRATIONS_ROOT = TEST_ROOT + "/migrations"
SCHEMA_ROOT     = TEST_ROOT + "/schema"
