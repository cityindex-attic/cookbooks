class MemberType < ActiveRecord::Base
  has_many :members
end
