class IRaiseOnDown < ActiveRecord::Migration
  def self.up
  end

  def self.down
    raise
  end
end